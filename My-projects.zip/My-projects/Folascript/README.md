#These are services/project I deployed in my home lab

# Fola
#This is just a simple script I created to install my custom applications on a fresh install ubuntu linux
#Apps are
#qbttorent
#playonlinux
#wine
#ssh
#xrdp for remote desktop
#update and upgrade OSs
