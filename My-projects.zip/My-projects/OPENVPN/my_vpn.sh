#!/bin/bash
#Run my VPN config file
#COPY YOUR OPENVPN CONFIG FILE IN THE DIRECTORY   /etc/openvpn/client/   AND RENAME THE FILE TO client.conf
#RUN THE COMMAND BELOW AND LEAVE THE TERMINAL OPEN 
sudo openvpn /etc/openvpn/client/client.conf

